function [OA_KNN,MA_KNN,Kappa_KNN,STDOA_KNN,STDMA_KNN,STDKappa_KNN,OA_LDA,MA_LDA,Kappa_LDA,STDOA_LDA,STDMA_LDA,STDKappa_LDA,OA_SVM,MA_SVM,Kappa_SVM,STDOA_SVM,STDMA_SVM,STDKappa_SVM,OA_KSRC,MA_KSRC,Kappa_KSRC,STDOA_KSRC,STDMA_KSRC,STDKappa_KSRC] = MHSPC_main(Dataset,classifier_names)

img_src = Dataset.A;
[W, H, L]=size(img_src);
img = reshape(img_src, W * H, L);

%% Initial Sv
options.t=1;
options.bSelfConnected = 0 ;
options.NeighborMode = 'KNN';
options.WeightMode = 'HeatKernel';
options.k = 5;
S = constructW(Dataset.X,options);
L = diag(sum(S,2))-S;

alphaSet = [0.001,0.01, 0.1, 1, 10, 100, 1000];
betaSet = [0.001, 0.01, 0.1, 1, 10, 100, 1000];



BandK = 5 : 5 : 60;
count = 1;
OA_KNN=zeros(1,length(BandK));
MA_KNN = zeros(1,length(BandK));
Kappa_KNN = zeros(1,length(BandK));
STDOA_KNN = zeros(1,length(BandK));
STDMA_KNN = zeros(1,length(BandK));
STDKappa_KNN = zeros(1,length(BandK));

OA_LDA=zeros(1,length(BandK));
MA_LDA = zeros(1,length(BandK));
Kappa_LDA = zeros(1,length(BandK));
STDOA_LDA = zeros(1,length(BandK));
STDMA_LDA = zeros(1,length(BandK));
STDKappa_LDA = zeros(1,length(BandK));

OA_SVM=zeros(1,length(BandK));
MA_SVM = zeros(1,length(BandK));
Kappa_SVM = zeros(1,length(BandK));
STDOA_SVM = zeros(1,length(BandK));
STDMA_SVM = zeros(1,length(BandK));
STDKappa_SVM = zeros(1,length(BandK));

OA_KSRC=zeros(1,length(BandK));
MA_KSRC = zeros(1,length(BandK));
Kappa_KSRC = zeros(1,length(BandK));
STDOA_KSRC = zeros(1,length(BandK));
STDMA_KSRC = zeros(1,length(BandK));
STDKappa_KSRC = zeros(1,length(BandK));
% IE = Entrop(Dataset.X);
for bandIndex = 1:length(BandK)
    OA_KNN(bandIndex) = 0; MA_KNN(bandIndex) = 0; Kappa_KNN(bandIndex) = 0; STDOA_KNN(bandIndex) = 0; STDMA_KNN(bandIndex) = 0; STDKappa_KNN(bandIndex) = 0;
    OA_LDA(bandIndex) = 0; MA_LDA(bandIndex) = 0; Kappa_LDA(bandIndex) = 0; STDOA_LDA(bandIndex) = 0; STDMA_LDA(bandIndex) = 0; STDKappa_LDA(bandIndex) = 0;
    OA_SVM(bandIndex) = 0; MA_SVM(bandIndex) = 0; Kappa_SVM(bandIndex) = 0; STDOA_SVM(bandIndex) = 0; STDMA_SVM(bandIndex) = 0; STDKappa_SVM(bandIndex) = 0;
    OA_KSRC(bandIndex) = 0; MA_KSRC(bandIndex) = 0; Kappa_KSRC(bandIndex) = 0; STDOA_KSRC(bandIndex) = 0; STDMA_KSRC(bandIndex) = 0; STDKappa_KSRC(bandIndex) = 0;
    for alphaIndex = 1 : length(alphaSet)
        for betaIndex = 1 : length(betaSet)
                maxIter = 30;
                [C] = MHSPC(img_src, alphaSet(alphaIndex), betaSet(betaIndex), BandK(bandIndex), maxIter, L);
                [max_c,CluRes]=max(C,[],2);
%                 CluRes = litekmeans(C,BandK(bandIndex), 'MaxIter',100, 'Replicates',20);
                Y = SelectBandFromClusRes(CluRes, BandK(bandIndex), img);
                
                % KNN
                [acc,Classify_map] = test_bs_accu(Y, Dataset, classifier_names{1});
                %             color_disp(Classify_map);
                %             PicPath = ['classification/' 'MGAGR.jpg'];
                %             print('-djpeg','-r300', PicPath);
                if acc.OA>OA_KNN(bandIndex)
                    OA_KNN(bandIndex) = acc.OA;
                    MA_KNN(bandIndex) = acc.MA;
                    Kappa_KNN(bandIndex) = acc.Kappa;
                    STDOA_KNN(bandIndex) = acc.STDOA;
                    STDMA_KNN(bandIndex) = acc.STDMA;
                    STDKappa_KNN(bandIndex) = acc.STDKappa;
                end
                
                % LDA
                [acc,Classify_map] = test_bs_accu(Y, Dataset, classifier_names{2});
                %             color_disp(Classify_map);
                %             PicPath = ['classification/' 'MGAGR.jpg'];
                %             print('-djpeg','-r300', PicPath);
                if acc.OA>OA_LDA(bandIndex)
                    OA_LDA(bandIndex) = acc.OA;
                    MA_LDA(bandIndex) = acc.MA;
                    Kappa_LDA(bandIndex) = acc.Kappa;
                    STDOA_LDA(bandIndex) = acc.STDOA;
                    STDMA_LDA(bandIndex) = acc.STDMA;
                    STDKappa_LDA(bandIndex) = acc.STDKappa;
                end
                
                % SVM
                [acc,Classify_map] = test_bs_accu(Y, Dataset, classifier_names{3});
                %             color_disp(Classify_map);
                %             PicPath = ['classification/' 'MGAGR.jpg'];
                %             print('-djpeg','-r300', PicPath);
                if acc.OA>OA_SVM(bandIndex)
                    OA_SVM(bandIndex) = acc.OA;
                    MA_SVM(bandIndex) = acc.MA;
                    Kappa_SVM(bandIndex) = acc.Kappa;
                    STDOA_SVM(bandIndex) = acc.STDOA;
                    STDMA_SVM(bandIndex) = acc.STDMA;
                    STDKappa_SVM(bandIndex) = acc.STDKappa;
                end
                
                % KSRC
                [acc,Classify_map] = test_bs_accu(Y, Dataset, classifier_names{2});
                %             color_disp(Classify_map);
                %             PicPath = ['classification/' 'MGAGR.jpg'];
                %             print('-djpeg','-r300', PicPath);
                if acc.OA>OA_KSRC(bandIndex)
                    OA_KSRC(bandIndex) = acc.OA;
                    MA_KSRC(bandIndex) = acc.MA;
                    Kappa_KSRC(bandIndex) = acc.Kappa;
                    STDOA_KSRC(bandIndex) = acc.STDOA;
                    STDMA_KSRC(bandIndex) = acc.STDMA;
                    STDKappa_KSRC(bandIndex) = acc.STDKappa;
                end                
                
        end
    end
end
