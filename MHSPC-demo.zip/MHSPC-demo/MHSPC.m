function [C] = MHSPC(X, alpha, beta, bandK, maxIter, L)

%
%% input:
%       dataset X (n times d, n for #samples, d for #features)
%       hyper parameters: alpha, gamma, sigma
%       the number of group: group_num
%       the label of group: group_label
%       the number of iteration: maxIter
%  output:
%       feature selection index: index
%       (for features) self-representation matrix: Z
%       (for samples) global similarity S
%       (for groups) weight matrix: W

[n1, n2, n] = size(X);

%% Initialize input parameters
P = rand(n1,bandK);
Q = rand(n2,bandK);
C = rand(n,bandK);
M = rand(bandK,n);
J = rand(n,bandK);
Y1 = rand(bandK,n);
Y2 = rand(n,bandK);
obj = zeros(maxIter, 1);

rho = 1.1;
mu = 1e-1;
max_mu = 1e10;
for iter = 1:maxIter
    disp(['alpha, beta, band: ',num2str(alpha),', ',num2str(beta),', ',num2str(bandK),', Iter: ',num2str(iter)]);
    
    %% update P
    X1 = double(tenmat(X,1));
    CQKR = KR(C, Q);
    P = P.*((X1*CQKR)./(P*CQKR'*CQKR));
    
    %% update Q
    X2 = double(tenmat(X,2));
    CPKR = KR(C, P);
    Q = Q.*((X2*CPKR)./(Q*CPKR'*CPKR));
    
    %% update C
    QPKR = KR(Q, P);
    X3 = double(tenmat(X,3));
    [Lsvd,M,Rsvd] = svd(2*QPKR'*X3' - beta*J'*L'+ mu*(M' - Y1'/mu + J - Y2/mu)');
    C = Rsvd*eye(n,bandK)*Lsvd';
    
    %% update M
    M = updateM(C,Y1,alpha,mu);
    
    %% update J
    J = C + Y2/mu-(beta/mu)*L'*C;
    
    %% update Y1 Y2
    Y1 = Y1 + mu*(C' - M);
    Y2 = Y2 + mu*(C - J);
    
    mu = rho*mu;
    
    %% calculate objective function value1
    %     disp('calculate obj-value...');
    %     CPABC = zeros(n1,n2,n);
    %     for cpI = 1:bandK
    %         CPABC = CPABC + A(:,cpI)'
    %     end
    obj(iter) = alpha*norm(M) + beta*trace(C'*L*J);
    
end


end