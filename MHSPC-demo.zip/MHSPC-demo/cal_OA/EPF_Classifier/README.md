

The files are the MATLAB source code for the two papers：

### EPF

Spectral-spatial hyperspectral image classification with edge-preserving filtering

IEEE Transactions on Geoscience and Remote Sensing, 2014.

### IFRF

Feature extraction of hyperspectral images with image fusion and recursive filtering

IEEE Transactions on Geoscience and Remote Sensing, 2014.

代码从湖南大学 康旭东 老师个人主页上下载，仅供科研使用
